This directory contains the Fiorano licenses. The Fiorano license is a read-only text file.
The extension of the license file is ".lic".

To view the details of a license, you can open it in any text editor.

All the Fiorano components are licensed, so you need a license for every component that you may want to run.

There can be one license file containing the licenses for all the components or multiple
license files containing the licenses for the different components.

To get a evaluation license, please contact sales@fiorano.com

To purchase a license, please contact sales@fiorano.com

To get a purchased license, please contact licensing@fiorano.com

To renew a license, please contact sales@fiorano.com

If you have trouble installing the license, please contact licensing@fiorano.com
